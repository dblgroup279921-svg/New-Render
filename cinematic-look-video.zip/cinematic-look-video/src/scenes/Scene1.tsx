// Scene 1 (cue 1) — Kinetic Typography hook  ->  Glossy UI "AI image tool" upload window.
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Photo } from "../components/Photo";
import { UploadIcon } from "../components/Icons";
import { Word } from "../components/Word";
import { theme } from "../theme";
import { S1, S1_BEAT_B } from "../timing";

const C = theme.colors;
const LIFT = (a: number, b: number, p: number) => a + (b - a) * p;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

// photo: state A (hook, right side) -> state B (inside the upload window)
const A = { cx: 1460, cy: 540, size: 500 };
const B = { cx: 960, cy: 500, size: 360 };
// UI window
const WIN = { x: 440, y: 170, w: 1040, h: 740, bar: 76 };
const DROP = { x: WIN.x + 60, y: WIN.y + WIN.bar + 36, w: WIN.w - 120, h: 440 };

export const Scene1: React.FC = () => {
  const frame = useCurrentFrame() + S1.from; // S1.from = 0
  const { fps } = useVideoConfig();
  const bB = S1_BEAT_B;
  const exitText = bB - 4;

  // photo
  const enter = spring({ frame: frame - 14, fps, config: theme.spring.smooth });
  const pb = spring({ frame: frame - bB - 2, fps, config: theme.spring.smooth });
  const float = Math.sin(frame / 26) * 6 * (1 - pb);
  const cx = LIFT(A.cx + (1 - enter) * 160, B.cx, pb);
  const cy = LIFT(A.cy, B.cy, pb) + float;
  const size = LIFT(A.size, B.size, pb);
  const rotY = LIFT(-12, 0, pb) * enter;
  const rotZ = LIFT(2, 0, pb);
  const photoOpacity = clamp01(enter);

  // window
  const w = spring({ frame: frame - bB, fps, config: theme.spring.smooth });
  const winOut = clamp01(w);
  // dashed drop-zone border runs
  const dash = (frame * 1.4) % 28;
  // photo landing ring pulse
  const land = interpolate(frame, [bB + 14, bB + 34], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  // button
  const btn = spring({ frame: frame - bB - 12, fps, config: theme.spring.bouncy });

  // underline under the hero line
  const ul = spring({ frame: frame - 24, fps, config: theme.spring.smooth });
  const ulOut = interpolate(frame, [exitText, exitText + 10], [1, 0], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <AbsoluteFill>
      {/* ---- beat A: kinetic hook ---- */}
      <div style={{ position: "absolute", left: 120, top: 292, width: 1180 }}>
        <div style={{ display: "flex", gap: 22 }}>
          <Word delay={0} size={92} color={C.textDim} weight={theme.weight.semi} exitAt={exitText}>সাধারণ</Word>
          <Word delay={4} size={92} color={C.textDim} weight={theme.weight.semi} exitAt={exitText}>ছবিকে</Word>
        </div>
        <div style={{ display: "flex", gap: 30, marginTop: -6 }}>
          <Word delay={10} size={150} pop exitAt={exitText} glow={C.glow} gradient={`linear-gradient(100deg, ${C.primary} 10%, ${C.accent} 95%)`}>সিনেমার</Word>
          <Word delay={14} size={150} exitAt={exitText}>দৃশ্যের</Word>
        </div>
        <div style={{ width: 560 * clamp01(ul) * ulOut, height: 8, borderRadius: 8, marginTop: -8, marginLeft: 12, background: `linear-gradient(90deg, ${C.primary}, ${C.accent})` }} />
        <div style={{ display: "flex", gap: 24, marginTop: 6 }}>
          <Word delay={22} size={104} exitAt={exitText}>মতো</Word>
          <Word delay={26} size={104} exitAt={exitText}>বানাতে</Word>
          <Word delay={30} size={104} exitAt={exitText}>চান?</Word>
        </div>
      </div>

      {/* ---- beat B: AI image tool window ---- */}
      <div
        style={{
          position: "absolute", left: WIN.x, top: WIN.y, width: WIN.w, height: WIN.h,
          opacity: winOut,
          transform: `translateY(${(1 - w) * 70}px) scale(${0.92 + 0.08 * w})`,
          borderRadius: theme.radius.window,
          background: `linear-gradient(180deg, ${C.glassStrong}, ${C.glass})`,
          border: `1.5px solid ${C.glassBorder}`,
          boxShadow: theme.shadow.card,
          overflow: "hidden",
        }}
      >
        {/* title bar */}
        <div style={{ height: WIN.bar, display: "flex", alignItems: "center", padding: "0 34px", borderBottom: `1px solid ${C.glassBorder}` }}>
          <div style={{ display: "flex", gap: 12 }}>
            {[C.textDim, C.textDim, C.textDim].map((c, i) => (
              <div key={i} style={{ width: 16, height: 16, borderRadius: 16, background: c, opacity: 0.5 }} />
            ))}
          </div>
          <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
            <div style={{ padding: "8px 26px", borderRadius: theme.radius.chip, background: C.glass, border: `1px solid ${C.glassBorder}`, fontFamily: theme.fonts.display, fontWeight: theme.weight.semi, fontSize: 30, color: C.text, letterSpacing: 0 }}>
              AI image tool
            </div>
          </div>
          <div style={{ width: 76 }} />
        </div>
        {/* button */}
        <div
          style={{
            position: "absolute", left: "50%", top: WIN.bar + 36 + DROP.h + 40, transform: `translateX(-50%) scale(${0.85 + 0.15 * btn})`, opacity: clamp01(btn),
            display: "flex", alignItems: "center", gap: 16, padding: "14px 40px", borderRadius: theme.radius.chip,
            background: C.glassStrong, border: `1.5px solid ${C.glassBorder}`,
          }}
        >
          <UploadIcon size={34} />
          <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.semi, fontSize: 34, color: C.text, letterSpacing: 0, lineHeight: 1.35 }}>ছবি আপলোড</span>
        </div>
      </div>

      {/* drop zone (dashed, animated) */}
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080} viewBox="0 0 1920 1080">
        <rect
          x={DROP.x} y={DROP.y} width={DROP.w} height={DROP.h} rx={30}
          fill="none" stroke={C.primary} strokeWidth={3} strokeDasharray="14 14" strokeDashoffset={-dash}
          opacity={winOut * 0.85}
        />
        <rect
          x={DROP.x - 10 * land} y={DROP.y - 10 * land} width={DROP.w + 20 * land} height={DROP.h + 20 * land} rx={36}
          fill="none" stroke={C.primary} strokeWidth={2} opacity={(1 - land) * 0.9 * winOut}
        />
      </svg>

      {/* ---- the photo (flat look), travels from hook to drop zone ---- */}
      <div
        style={{
          position: "absolute", left: cx - size / 2, top: cy - size / 2, width: size, height: size,
          opacity: photoOpacity,
          transform: `perspective(1400px) rotateY(${rotY}deg) rotateZ(${rotZ}deg)`,
          borderRadius: LIFT(theme.radius.image, 28, pb), overflow: "hidden",
          border: `1.5px solid ${C.glassBorder}`,
          boxShadow: theme.shadow.card,
        }}
      >
        <Photo look="flat" zoom={1.03 + 0.04 * Math.sin(frame / 60)} />
      </div>
    </AbsoluteFill>
  );
};
