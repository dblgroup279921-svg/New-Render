// Scene 3 (cue 3) — Before/After split reveal ("ফলাফল দেখুন") + checklist tip ("পরিষ্কার ছবি").
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Photo } from "../components/Photo";
import { Word } from "../components/Word";
import { theme } from "../theme";
import { S3, S3_SWEEP, S3_TIP_MAIN, S3_TIP_SUB } from "../timing";

const C = theme.colors;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const IMG = { x: 150, y: 150, size: 780 };

export const Scene3: React.FC = () => {
  const frame = useCurrentFrame(); // local
  const { fps } = useVideoConfig();
  const sweep = S3_SWEEP - S3.from;
  const tipSub = S3_TIP_SUB - S3.from;
  const tipMain = S3_TIP_MAIN - S3.from;

  // image panel entrance
  const panel = spring({ frame: frame - 4, fps, config: theme.spring.smooth });
  // divider position: 100% (all ordinary) -> 50%, then a gentle live wobble
  const sw = interpolate(frame, [sweep, sweep + 24], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const settled = clamp01((frame - (sweep + 24)) / 20);
  const d = 100 - 50 * sw + Math.sin(frame / 22) * 2.2 * settled;
  const glowAmt = clamp01((frame - sweep) / 24);
  const labels = spring({ frame: frame - (sweep + 22), fps, config: theme.spring.bouncy });

  // tip card
  const card = spring({ frame: frame - tipSub, fps, config: theme.spring.smooth });
  const tick = interpolate(frame, [tipMain + 6, tipMain + 18], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const tickPop = spring({ frame: frame - (tipMain + 6), fps, config: theme.spring.bouncy });
  const breathe = 1 + Math.sin(frame / 24) * 0.006;

  return (
    <AbsoluteFill>
      {/* before / after panel */}
      <div
        style={{
          position: "absolute", left: IMG.x, top: IMG.y, width: IMG.size, height: IMG.size,
          opacity: clamp01(panel), transform: `translateY(${(1 - panel) * 60}px) scale(${(0.93 + 0.07 * panel) * breathe})`,
          borderRadius: theme.radius.image, overflow: "hidden",
          border: `1.5px solid ${C.glassBorder}`,
          boxShadow: `${theme.shadow.card}, 0 0 ${80 * glowAmt}px ${C.glowAccent}`, // one hero glow per frame: panel glows accent, not hero
        }}
      >
        <div style={{ position: "absolute", inset: 0 }}>
          <Photo look="flat" />
        </div>
        <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 0 0 ${d}%)` }}>
          <Photo look="cine" zoom={1.02 + 0.02 * clamp01(sw)} />
        </div>
        {/* divider */}
        <div style={{ position: "absolute", top: 0, bottom: 0, left: `${d}%`, width: 4, marginLeft: -2, background: C.text, boxShadow: `0 0 24px ${C.glow}`, opacity: sw > 0 ? 1 : 0 }} />
        <div
          style={{
            position: "absolute", top: "50%", left: `${d}%`, width: 68, height: 68, marginLeft: -34, marginTop: -34, borderRadius: 68,
            background: C.bg, border: `3px solid ${C.text}`, display: "flex", alignItems: "center", justifyContent: "center",
            opacity: sw > 0 ? 1 : 0,
          }}
        >
          <svg width={36} height={36} viewBox="0 0 36 36" fill="none" stroke={C.text} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round">
            <path d="M14 10l-8 8 8 8M22 10l8 8-8 8" />
          </svg>
        </div>
        {/* labels */}
        {[
          { text: "সাধারণ", left: 28 },
          { text: "সিনেমাটিক", right: 28 },
        ].map((l, i) => (
          <div
            key={l.text}
            style={{
              position: "absolute", bottom: 28, ...(l.left !== undefined ? { left: l.left } : { right: l.right }),
              opacity: clamp01(labels - i * 0.05), transform: `translateY(${(1 - labels) * 20}px) scale(${0.85 + 0.15 * labels})`,
              padding: "6px 28px", borderRadius: theme.radius.chip, fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy,
              fontSize: 34, lineHeight: 1.4, letterSpacing: 0,
              background: C.bg, color: C.text, border: `1.5px solid ${C.glassBorder}`,
            }}
          >
            {l.text}
          </div>
        ))}
      </div>

      {/* headline */}
      <div style={{ position: "absolute", left: 1010, top: 130 }}>
        <div>
          <Word delay={8} size={168} pop gradient={`linear-gradient(100deg, ${C.primary} 10%, ${C.accent} 95%)`}>ফলাফল</Word>
        </div>
        <div style={{ marginTop: -14 }}>
          <Word delay={14} size={168}>দেখুন</Word>
        </div>
      </div>

      {/* checklist tip card */}
      <div
        style={{
          position: "absolute", left: 1010, top: 640, width: 780, height: 250,
          opacity: clamp01(card), transform: `translateY(${(1 - card) * 60}px) scale(${0.94 + 0.06 * card})`,
          borderRadius: theme.radius.card,
          background: `linear-gradient(180deg, ${C.glassStrong}, ${C.glass})`,
          border: `1.5px solid ${C.glassBorder}`, boxShadow: theme.shadow.card,
          display: "flex", alignItems: "center", gap: 36, padding: "0 44px",
        }}
      >
        <div
          style={{
            width: 110, height: 110, borderRadius: 110, flexShrink: 0,
            background: tick > 0 ? C.primary : C.glass, border: `2px solid ${tick > 0 ? C.primary : C.glassBorder}`,
            boxShadow: tick > 0 ? `0 0 ${60 * clamp01(tickPop)}px ${C.glow}` : "none",
            transform: `scale(${tick > 0 ? 0.8 + 0.2 * tickPop : 1})`,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <svg width={66} height={66} viewBox="0 0 48 48" fill="none" stroke={C.ink} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round">
            <path d="M10 25l10 10 19-21" strokeDasharray={50} strokeDashoffset={50 * (1 - tick)} />
          </svg>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ opacity: clamp01(card), fontFamily: theme.fonts.display, fontWeight: theme.weight.semi, fontSize: 38, lineHeight: 1.4, letterSpacing: 0, color: C.textDim }}>ভালো ফলের জন্য</div>
          <div style={{ display: "flex", gap: 22 }}>
            <Word delay={tipMain} size={78}>পরিষ্কার</Word>
            <Word delay={tipMain + 4} size={78}>ছবি</Word>
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
