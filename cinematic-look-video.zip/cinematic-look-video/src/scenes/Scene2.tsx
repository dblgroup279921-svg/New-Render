// Scene 2 (cue 2) — prompt bar with typing + three Glass Cards (one per keyword) + Generate press.
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { DepthIcon, LightIcon, SkinIcon } from "../components/Icons";
import { Photo } from "../components/Photo";
import { theme } from "../theme";
import { S2, S2_ITEMS, S2_PRESS } from "../timing";

const C = theme.colors;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

const PHRASES = ["Cinematic lighting,", " shallow depth of field,", " realistic skin texture."];
const FULL = PHRASES.join("");
const CARDS = [
  { title: "Cinematic lighting", sub: "সিনেমাটিক আলো", Icon: LightIcon },
  { title: "Shallow depth of field", sub: "ফোকাস ও ডেপথ", Icon: DepthIcon },
  { title: "Realistic skin texture", sub: "ত্বকের টেক্সচার", Icon: SkinIcon },
];

const BAR = { x: 160, y: 104, w: 1600, h: 270 };
const CARD = { w: 500, h: 470, y: 456, gap: 50 };
const cardX = (i: number) => BAR.x + i * (CARD.w + CARD.gap);

export const Scene2: React.FC = () => {
  const frame = useCurrentFrame(); // local to the scene
  const { fps } = useVideoConfig();
  const items = S2_ITEMS.map((f) => f - S2.from);
  const press = S2_PRESS - S2.from;

  // typing: phrase i is typed in [items[i]-20, items[i]+24] (never before frame 12 of the scene)
  let shown = 0;
  PHRASES.forEach((ph, i) => {
    const a = Math.max(12, items[i] - 20);
    const b = items[i] + 24;
    const t = interpolate(frame, [a, b], [0, 1], { easing: theme.ease.type, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
    shown += Math.round(t * ph.length);
  });
  const typed = FULL.slice(0, shown);
  const rest = FULL.slice(shown);
  const typing = shown > 0 && shown < FULL.length;
  const cursorOn = typing || Math.floor(frame / 15) % 2 === 0;

  // bar entrance
  const bar = spring({ frame: frame - 8, fps, config: theme.spring.smooth });
  const thumb = spring({ frame: frame - 14, fps, config: theme.spring.bouncy });

  // Generate button press
  const pr = interpolate(frame, [press, press + 4, press + 10], [1, 0.93, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const fill = interpolate(frame, [press, press + 6], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const ripple = interpolate(frame, [press, press + 18], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <AbsoluteFill>
      {/* prompt bar */}
      <div
        style={{
          position: "absolute", left: BAR.x, top: BAR.y, width: BAR.w, height: BAR.h,
          opacity: clamp01(bar), transform: `translateY(${(1 - bar) * 50}px) scale(${0.95 + 0.05 * bar})`,
          borderRadius: theme.radius.window,
          background: `linear-gradient(180deg, ${C.glassStrong}, ${C.glass})`,
          border: `1.5px solid ${C.glassBorder}`, boxShadow: theme.shadow.card,
        }}
      >
        {/* photo thumbnail */}
        <div
          style={{
            position: "absolute", left: 40, top: 40, width: 190, height: 190, borderRadius: 28, overflow: "hidden",
            border: `1.5px solid ${C.glassBorder}`, opacity: clamp01(thumb), transform: `scale(${0.8 + 0.2 * thumb})`,
          }}
        >
          <Photo look="flat" />
        </div>
        {/* label */}
        <div style={{ position: "absolute", left: 272, top: 30, display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 12, height: 12, borderRadius: 12, background: C.textDim }} />
          <span style={{ fontFamily: theme.fonts.mono, fontWeight: theme.weight.mono, fontSize: 24, color: C.textDim, letterSpacing: 0 }}>Prompt</span>
        </div>
        {/* typed prompt — the untyped rest is laid out invisibly so text never reflows */}
        <div
          style={{
            position: "absolute", left: 272, top: 76, width: 1000,
            fontFamily: theme.fonts.mono, fontWeight: theme.weight.mono, fontSize: 38, lineHeight: 1.5, letterSpacing: 0,
            color: C.text, whiteSpace: "pre-wrap",
          }}
        >
          <span>{typed}</span>
          <span style={{ display: "inline-block", width: 0, height: 0, position: "relative" }}>
            <span style={{ position: "absolute", left: 3, bottom: -12, width: 4, height: 46, borderRadius: 2, background: C.primary, opacity: cursorOn ? 1 : 0 }} />
          </span>
          <span style={{ color: "transparent" }}>{rest}</span>
        </div>
        {/* Generate button */}
        <div style={{ position: "absolute", right: 44, top: (BAR.h - 92) / 2, width: 270, height: 92 }}>
          <div
            style={{
              position: "absolute", inset: -14 * ripple, borderRadius: theme.radius.chip,
              border: `2px solid ${C.primary}`, opacity: ripple > 0 ? (1 - ripple) * 0.9 : 0,
            }}
          />
          <div
            style={{
              position: "absolute", inset: 0, borderRadius: theme.radius.chip, transform: `scale(${pr})`,
              display: "flex", alignItems: "center", justifyContent: "center",
              background: fill > 0 ? C.primary : C.glassStrong,
              opacity: 1,
              border: `1.5px solid ${fill > 0 ? C.primary : C.glassBorder}`,
              boxShadow: fill > 0 ? `0 0 ${50 * (1 - ripple * 0.6)}px ${C.glow}` : "none",
              fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 36, letterSpacing: 0,
              color: fill > 0 ? C.ink : C.text,
            }}
          >
            Generate
          </div>
        </div>
      </div>

      {/* connectors + glass cards */}
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080} viewBox="0 0 1920 1080">
        {CARDS.map((_, i) => {
          const d = clamp01(interpolate(frame, [items[i] - 8, items[i] + 6], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" }));
          const x = cardX(i) + CARD.w / 2;
          return (
            <line key={i} x1={x} y1={BAR.y + BAR.h} x2={x} y2={BAR.y + BAR.h + (CARD.y - BAR.y - BAR.h) * d} stroke={C.textDim} strokeOpacity={0.55} strokeWidth={2.5} strokeDasharray="6 8" strokeLinecap="round" />
          );
        })}
      </svg>
      {CARDS.map(({ title, sub, Icon }, i) => {
        const t = items[i];
        const p = spring({ frame: frame - t, fps, config: theme.spring.smooth });
        const active = interpolate(frame, [t, t + 8, t + 46], [0, 1, 0.12], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        const idle = Math.sin(frame / 28 + i * 2) * 4;
        return (
          <div
            key={title}
            style={{
              position: "absolute", left: cardX(i), top: CARD.y, width: CARD.w, height: CARD.h,
              opacity: clamp01(p), transform: `translateY(${(1 - p) * 70 + idle * p}px) scale(${0.9 + 0.1 * p})`,
              borderRadius: theme.radius.card,
              background: `linear-gradient(180deg, ${C.glassStrong}, ${C.glass})`,
              border: `1.5px solid ${C.primary}${Math.round((0.18 + 0.82 * active) * 255).toString(16).padStart(2, "0")}`,
              boxShadow: `${theme.shadow.card}, 0 0 ${70 * active}px ${C.glow}`,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 18,
            }}
          >
            <div style={{ transform: `scale(${1.05 + 0.08 * active})` }}>
              <Icon />
            </div>
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 42, color: C.text, letterSpacing: 0, lineHeight: 1.3, textAlign: "center" }}>{title}</div>
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.semi, fontSize: 32, color: C.textDim, letterSpacing: 0, lineHeight: 1.4, textAlign: "center" }}>{sub}</div>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
