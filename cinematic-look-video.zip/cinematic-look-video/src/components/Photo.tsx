import React from "react";
import { Img, staticFile } from "remotion";
import { theme } from "../theme";

/** The user's photo, in one of two looks: "flat" (ordinary) or "cine" (original, cinematic). */
export const Photo: React.FC<{ look: "flat" | "cine"; zoom?: number; shiftX?: number; style?: React.CSSProperties }> = ({ look, zoom = 1, shiftX = 0, style }) => (
  <Img
    src={staticFile("photo.jpg")}
    style={{
      width: "100%",
      height: "100%",
      objectFit: "cover",
      filter: look === "flat" ? theme.filter.flat : theme.filter.cine,
      transform: `scale(${zoom}) translateX(${shiftX}px)`,
      ...style,
    }}
  />
);
