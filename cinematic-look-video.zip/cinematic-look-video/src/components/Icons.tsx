import React from "react";
import { theme } from "../theme";

const C = theme.colors;

/** Spotlight beam over a subject — "Cinematic lighting" */
export const LightIcon: React.FC = () => (
  <svg width={260} height={170} viewBox="0 0 260 170">
    <defs>
      <linearGradient id="ic-beam" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={C.primary} stopOpacity="0.6" />
        <stop offset="1" stopColor={C.primary} stopOpacity="0" />
      </linearGradient>
    </defs>
    <polygon points="108,36 152,36 214,160 46,160" fill="url(#ic-beam)" />
    <rect x="90" y="12" width="80" height="28" rx="12" fill={C.text} />
    <rect x="116" y="38" width="28" height="8" rx="3" fill={C.textDim} />
    <circle cx="130" cy="146" r="13" fill={C.accent} />
  </svg>
);

/** Sharp centre, soft rings — "Shallow depth of field" */
export const DepthIcon: React.FC = () => (
  <svg width={260} height={170} viewBox="0 0 260 170">
    <defs>
      <filter id="ic-b6"><feGaussianBlur stdDeviation="6" /></filter>
      <filter id="ic-b3"><feGaussianBlur stdDeviation="3" /></filter>
    </defs>
    <circle cx="130" cy="85" r="74" fill="none" stroke={C.text} strokeOpacity="0.3" strokeWidth="6" filter="url(#ic-b6)" />
    <circle cx="130" cy="85" r="52" fill="none" stroke={C.text} strokeOpacity="0.5" strokeWidth="6" filter="url(#ic-b3)" />
    <circle cx="130" cy="85" r="30" fill="none" stroke={C.text} strokeWidth="6" />
    <circle cx="130" cy="85" r="8" fill={C.accent} />
  </svg>
);

/** Fine dot texture inside a lens — "Realistic skin texture" */
export const SkinIcon: React.FC = () => {
  const dots: React.ReactNode[] = [];
  for (let i = 0; i < 11; i++) {
    for (let j = 0; j < 8; j++) {
      const x = 40 + i * 18 + (j % 2) * 9;
      const y = 22 + j * 18;
      if (Math.hypot(x - 130, y - 85) > 70) continue;
      const r = 1.6 + 1.7 * Math.abs(Math.sin(i * 1.7 + j * 2.3));
      dots.push(<circle key={`${i}-${j}`} cx={x} cy={y} r={r} fill={C.text} fillOpacity={0.55 + 0.4 * Math.abs(Math.cos(i + j))} />);
    }
  }
  return (
    <svg width={260} height={170} viewBox="0 0 260 170">
      <circle cx="130" cy="85" r="76" fill="none" stroke={C.textDim} strokeOpacity="0.6" strokeWidth="5" />
      {dots}
      <line x1="186" y1="141" x2="226" y2="168" stroke={C.accent} strokeWidth="9" strokeLinecap="round" />
    </svg>
  );
};

export const UploadIcon: React.FC<{ size?: number; color?: string }> = ({ size = 52, color = C.text }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke={color} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
    <path d="M24 34V10M14 20l10-10 10 10" />
    <path d="M8 36v4h32v-4" />
  </svg>
);
