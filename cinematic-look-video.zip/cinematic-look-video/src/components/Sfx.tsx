import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { SFX_PLAN } from "../sfxPlan";

/** All SFX, placed on absolute frames (they also play in Remotion Studio preview). */
export const SfxLayer: React.FC = () => (
  <>
    {SFX_PLAN.map((e, i) => (
      <Sequence key={i} from={Math.max(0, e.frame)} layout="none">
        <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.volume} />
      </Sequence>
    ))}
  </>
);
