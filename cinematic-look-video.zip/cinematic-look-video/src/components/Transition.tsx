import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { TRANSITIONS, TRANSITION_FRAMES } from "../timing";

const PANEL_W = 2400;
const SKEW = -12;

/** Neon swipe panel that hides each scene cut (centred on the cue boundary). */
export const Transitions: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      {TRANSITIONS.map((b) => {
        const t = frame - (b - TRANSITION_FRAMES / 2);
        if (t < 0 || t > TRANSITION_FRAMES) return null;
        const p = interpolate(t, [0, TRANSITION_FRAMES], [0, 1], {
          easing: theme.ease.inOut,
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        });
        // p = 0.5 -> panel exactly covers the screen
        const left = interpolate(p, [0, 1], [-PANEL_W - 300, 1920 + 300]);
        return (
          <div
            key={b}
            style={{
              position: "absolute", top: -200, height: 1480, width: PANEL_W, left,
              transform: `skewX(${SKEW}deg)`,
              background: `linear-gradient(90deg, ${theme.colors.bgAlt}, ${theme.colors.bg})`,
              boxShadow: `-14px 0 0 0 ${theme.colors.primary}, -34px 0 60px 0 ${theme.colors.glow}, 22px 0 0 0 ${theme.colors.accent}, 40px 0 60px 0 ${theme.colors.glowAccent}`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};
