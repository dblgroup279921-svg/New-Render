import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_IN_RENDER, VOICEOVER_IN_STUDIO } from "../config";

/**
 * Plays public/voiceover.mp3 for sync-checking — only if the file exists.
 * Studio: controlled by VOICEOVER_IN_STUDIO. Render: off unless VOICEOVER_IN_RENDER is true.
 * If the file is missing it silently renders nothing.
 */
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const enabled = env.isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_STUDIO;
  // Only a real render needs to wait for the check; Studio preview never blocks.
  const [handle] = useState(() => (enabled && env.isRendering ? delayRender("voiceover.mp3 existence check") : null));
  const [found, setFound] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    const done = () => {
      if (handle !== null) continueRender(handle);
    };
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive && r.ok && /audio|mpeg|octet-stream/i.test(type)) setFound(true);
      })
      .catch(() => undefined)
      .finally(done);
    return () => {
      alive = false;
    };
  }, [enabled, handle]);

  if (!enabled || !found) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
