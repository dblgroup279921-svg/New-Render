import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

type Props = {
  children: string;
  /** local frame (inside the current Sequence) at which the word starts entering */
  delay: number;
  size: number;
  weight?: number;
  color?: string;
  /** CSS gradient for a gradient keyword */
  gradient?: string;
  /** bouncy accent pop instead of the snappy default */
  pop?: boolean;
  /** local frame at which the word starts leaving (10 frames, faster than entrance) */
  exitAt?: number;
  glow?: string;
};

/**
 * One whole Bangla/Latin word. Words are the smallest animated unit:
 * never split into letters (conjuncts / kar-marks / ref would break). letterSpacing stays 0.
 */
export const Word: React.FC<Props> = ({ children, delay, size, weight = theme.weight.heavy, color = theme.colors.text, gradient, pop, exitAt, glow }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: pop ? theme.spring.bouncy : theme.spring.snappy });
  const x =
    exitAt === undefined
      ? 0
      : interpolate(frame, [exitAt, exitAt + 10], [0, 1], {
          easing: theme.ease.in,
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        });
  const vis = Math.max(0, Math.min(1, p)) * (1 - x);
  return (
    <span
      style={{
        display: "inline-block",
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.35,
        letterSpacing: 0,
        whiteSpace: "nowrap",
        padding: "0.04em 0.06em",
        opacity: vis,
        transform: `translateY(${(1 - p) * 34 - x * 30}px) scale(${(pop ? 0.82 : 0.92) + (pop ? 0.18 : 0.08) * p})`,
        filter: `blur(${Math.max(0, (1 - p) * 8)}px)`,
        ...(gradient
          ? { backgroundImage: gradient, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }
          : { color }),
        ...(glow ? { textShadow: `0 0 50px ${glow}` } : {}),
      }}
    >
      {children}
    </span>
  );
};
