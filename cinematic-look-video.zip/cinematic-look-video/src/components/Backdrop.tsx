import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

// Neon tube polylines echoing the wall lights in the user's photo (kept low-key behind content).
const TUBES: { pts: string; color: string; phase: number }[] = [
  { pts: "-40,830 230,560 90,300 350,60", color: theme.colors.primary, phase: 0 },
  { pts: "1960,190 1700,480 1860,760 1600,1050", color: theme.colors.accent, phase: 1.6 },
  { pts: "690,-20 900,140 1190,-20", color: theme.colors.primary, phase: 3.1 },
  { pts: "560,1100 820,950 1110,1100", color: theme.colors.accent, phase: 4.4 },
];

export const Backdrop: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
          top: -520, left: -380 + d1, filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.primary}2E, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1100, height: 1100, borderRadius: "50%",
          bottom: -520, right: -330 - d2, filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.accent}26, transparent 64%)`,
        }}
      />
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0 }}>
        {[true, false].map((glow) => (
          <g key={String(glow)} style={glow ? { filter: "blur(10px)" } : undefined}>
            {TUBES.map((t, i) => {
              const pulse = 0.62 + 0.38 * Math.sin(frame / 38 + t.phase);
              const drift = Math.sin(frame / 90 + t.phase) * 8;
              return (
                <polyline
                  key={i}
                  points={t.pts}
                  fill="none"
                  stroke={t.color}
                  strokeWidth={glow ? 16 : 5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  opacity={(glow ? 0.28 : 0.4) * pulse}
                  transform={`translate(0 ${drift})`}
                />
              );
            })}
          </g>
        ))}
      </svg>
    </AbsoluteFill>
  );
};
