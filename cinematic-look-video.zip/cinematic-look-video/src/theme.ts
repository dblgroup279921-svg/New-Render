// theme.ts — single source of truth: colours, easings, springs, fonts, radii, shadows.
// Colour scheme: "Neon Studio" (dark, cool) — matches the neon wall in the user's photo.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#0B1118",
    bgAlt: "#111B26",
    primary: "#19D3C5", // HERO — keep to ~one dominant element per frame
    accent: "#FF4FD8",
    text: "#F2F7FA",
    textDim: "#93A7B5",
    ink: "#07101A", // dark text on hero-coloured fills
    glass: "rgba(242,247,250,0.06)",
    glassStrong: "rgba(242,247,250,0.11)",
    glassBorder: "rgba(242,247,250,0.16)",
    glow: "rgba(25,211,197,0.45)",
    glowAccent: "rgba(255,79,216,0.35)",
    shadow: "rgba(0,0,0,0.6)",
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", sans-serif', // Bangla + Latin
    mono: '"JetBrains Mono", "Hind Siliguri", monospace',
  },
  weight: { semi: 600, heavy: 700, mono: 500 },
  radius: { window: 40, card: 36, chip: 999, small: 20, image: 40 },
  shadow: {
    card: "0 40px 90px -24px rgba(0,0,0,0.65)",
    soft: "0 18px 40px -16px rgba(0,0,0,0.55)",
  },
  // photo treatments (same photo, two looks)
  filter: {
    flat: "saturate(0.2) contrast(0.76) brightness(1.2)", // "ordinary photo"
    cine: "saturate(1.06) contrast(1.04)", // "cinematic"
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    type: Easing.bezier(0.33, 1, 0.68, 1), // typing / gentle ease-out
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
