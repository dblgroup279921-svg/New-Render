// Every number here is derived from the SRT cues (src/cues.ts) — nothing is hand-placed.
import { CUES } from "./cues";
import { FPS, LEAD } from "./config";

const sec2f = (s: number) => Math.round(s * FPS);

/** Scene boundaries = cue boundaries. */
export const B1 = sec2f(CUES[0].end); // cue 1 -> cue 2
export const B2 = Math.round(((CUES[1].end + CUES[2].start) / 2) * FPS); // cue 2 -> cue 3 (midpoint of the 0.02s gap)
export const TOTAL = Math.ceil(CUES[CUES.length - 1].end * FPS);

/** Absolute frame where `marker` is spoken inside cue `i` (character-proportional), minus the visual lead. */
export const markerFrame = (i: number, marker: string, lead = LEAD): number => {
  const c = CUES[i];
  const k = c.text.indexOf(marker);
  if (k < 0) throw new Error(`marker "${marker}" not found in cue ${i + 1}`);
  const frac = k / c.text.length;
  return Math.round((c.start + frac * (c.end - c.start)) * FPS) - lead;
};

/** n items spread at equal intervals through cue `i` (slot centres), minus the visual lead. */
export const equalFrames = (i: number, n: number, lead = LEAD): number[] => {
  const c = CUES[i];
  const dur = c.end - c.start;
  return Array.from({ length: n }, (_, k) => Math.round((c.start + (dur * (k + 0.5)) / n) * FPS) - lead);
};

// ---- scene 1 (cue 1): hook, then "ছবিটি AI image tool দিন" --------------
export const S1 = { from: 0, to: B1 };
export const S1_BEAT_B = markerFrame(0, "ছবিটি");

// ---- scene 2 (cue 2): prompt + three keywords + "এবার" -------------------
export const S2 = { from: B1, to: B2 };
export const S2_ITEMS = equalFrames(1, 3); // absolute frames
export const S2_PRESS = markerFrame(1, "এবার");

// ---- scene 3 (cue 3): result reveal + clean-photo tip ---------------------
export const S3 = { from: B2, to: TOTAL };
// the sweep starts on "দেখুন" ("see the result") — after the swipe panel has cleared the cut
export const S3_SWEEP = markerFrame(2, "দেখুন");
export const S3_TIP_SUB = markerFrame(2, "ভালো");
export const S3_TIP_MAIN = markerFrame(2, "পরিষ্কার");

/** Transition panel: centred on each scene boundary. */
export const TRANSITIONS = [B1, B2];
export const TRANSITION_FRAMES = 16;
