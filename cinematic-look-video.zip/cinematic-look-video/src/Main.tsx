import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { Backdrop } from "./components/Backdrop";
import { Overlay } from "./components/Overlay";
import { PreviewAudio } from "./components/PreviewAudio";
import { SfxLayer } from "./components/Sfx";
import { Transitions } from "./components/Transition";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { S1, S2, S3 } from "./timing";

export const Main: React.FC = () => (
  <AbsoluteFill>
    <Backdrop />
    <Sequence from={S1.from} durationInFrames={S1.to - S1.from}>
      <Scene1 />
    </Sequence>
    <Sequence from={S2.from} durationInFrames={S2.to - S2.from}>
      <Scene2 />
    </Sequence>
    <Sequence from={S3.from} durationInFrames={S3.to - S3.from}>
      <Scene3 />
    </Sequence>
    <Transitions />
    <Overlay />
    <SfxLayer />
    <PreviewAudio />
  </AbsoluteFill>
);
