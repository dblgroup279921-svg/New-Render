// SFX events. Frames come from timing.ts (SRT-derived). Volumes 0.2–0.35, never over the voiceover.
// Per-sound base level compensates loudness differences measured by scripts/check-sfx.mjs.
import { B1, B2, S1_BEAT_B, S2_ITEMS, S2_PRESS, S3_SWEEP, S3_TIP_MAIN, S3_TIP_SUB, TRANSITION_FRAMES } from "./timing";

export type SfxName = "pop" | "pop2" | "click" | "whoosh" | "chime" | "thud";
export type SfxEvent = { name: SfxName; frame: number; volume: number };

const half = Math.round(TRANSITION_FRAMES / 2);

export const SFX_PLAN: SfxEvent[] = [
  // scene 1
  { name: "whoosh", frame: 0, volume: 0.26 }, // headline entry
  { name: "thud", frame: 12, volume: 0.2 }, // hook word lands (soft)
  { name: "pop", frame: S1_BEAT_B + 2, volume: 0.26 }, // AI tool window
  { name: "pop2", frame: S1_BEAT_B + 16, volume: 0.24 }, // photo drops in
  // transition 1
  { name: "whoosh", frame: B1 - half - 2, volume: 0.3 },
  // scene 2
  { name: "pop", frame: B1 + 10, volume: 0.24 }, // prompt window
  { name: "pop", frame: S2_ITEMS[0], volume: 0.26 }, // keyword card 1
  { name: "pop2", frame: S2_ITEMS[1], volume: 0.25 }, // keyword card 2
  { name: "pop", frame: S2_ITEMS[2], volume: 0.27 }, // keyword card 3
  { name: "click", frame: S2_PRESS, volume: 0.34 }, // generate button
  // transition 2
  { name: "whoosh", frame: B2 - half - 2, volume: 0.3 },
  // scene 3
  { name: "chime", frame: S3_SWEEP + 20, volume: 0.26 }, // result revealed
  { name: "pop", frame: S3_TIP_SUB, volume: 0.25 }, // tip card
  { name: "click", frame: S3_TIP_MAIN + 8, volume: 0.32 }, // tick mark
];
