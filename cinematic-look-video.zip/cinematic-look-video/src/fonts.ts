// Fonts come from @remotion/google-fonts (bundled into the Remotion build, no manual files).
// loadFont() blocks rendering until the font is ready.
import { loadFont as loadHind } from "@remotion/google-fonts/HindSiliguri";
import { loadFont as loadMono } from "@remotion/google-fonts/JetBrainsMono";

loadHind("normal", { weights: ["500", "600", "700"], subsets: ["bengali", "latin"] });
loadMono("normal", { weights: ["500"], subsets: ["latin"] });
