import React from "react";
import { Composition } from "remotion";
import "./fonts";
import { Main } from "./Main";
import { FPS, HEIGHT, WIDTH } from "./config";
import { TOTAL } from "./timing";

export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL} fps={FPS} width={WIDTH} height={HEIGHT} />
);
