// Project-level settings (not styling — styling lives in theme.ts).
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

/** Visuals enter this many frames BEFORE the related spoken words. */
export const LEAD = 5;

/** public/voiceover.mp3 (if present) plays in Remotion Studio preview. */
export const VOICEOVER_IN_STUDIO = true;
/** Keep false to render the video with SFX only. Set true to bake the voiceover into the MP4. */
export const VOICEOVER_IN_RENDER = false;
