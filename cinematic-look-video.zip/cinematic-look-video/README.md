# Cinematic Look — Remotion motion graphics

কম্পোজিশন: `Main` · 1920×1080 · 30fps · দৈর্ঘ্য SRT থেকে (≈16.4s) · কালার স্কিম: Neon Studio

```bash
npm install                 # একবারই
npx remotion studio         # প্রিভিউ
npx remotion render src/index.ts Main out/video.mp4
```

- `script.srt` — একমাত্র টাইমিং সোর্স। বদলালে `npm run cues` চালান (`src/cues.ts` নতুন করে তৈরি হয়)।
- `public/voiceover.mp3` রাখলে Studio-তে সিঙ্ক শোনা যাবে। MP4-তেও মেশাতে চাইলে `src/config.ts`-এ `VOICEOVER_IN_RENDER = true`।
- `public/photo.jpg` — আপনার ছবি। `public/sfx/` — সিন্থেসাইজ করা SFX (`npm run sfx` দিয়ে আবার বানানো/যাচাই করা যায়)।
- রং, ফন্ট, ইজিং, spring — সব `src/theme.ts`-এ।
- ফন্ট (Hind Siliguri, JetBrains Mono) `@remotion/google-fonts` থেকে লোড হয়; প্রথমবার ইন্টারনেট লাগতে পারে।
