// Synthesises a small, clean UI/motion-graphics SFX kit (16-bit mono WAV, 48 kHz).
// pop / pop2 (pitch variant) / click / whoosh / chime / thud   -> public/sfx/
// No plain sine/square beeps: pitch-dropped pops, HP-filtered noise clicks,
// band-pass noise sweeps, detuned soft plucks, all with soft attack, fast decay,
// gentle low-pass and a very short reverb.
import fs from "node:fs";

const SR = 48000;
const OUT = new URL("../public/sfx/", import.meta.url);
fs.mkdirSync(OUT, { recursive: true });

const noiseGen = (seed) => {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
};
const N = (sec) => Math.round(sec * SR);

const lp1 = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  const y = new Float32Array(x.length);
  let z = 0;
  for (let i = 0; i < x.length; i++) { z += a * (x[i] - z); y[i] = z; }
  return y;
};
const hp1 = (x, fc) => {
  const l = lp1(x, fc);
  const y = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) y[i] = x[i] - l[i];
  return y;
};
// Chamberlin state-variable band-pass, centre frequency can sweep per sample.
const bandpass = (x, fcAt, Q) => {
  const y = new Float32Array(x.length);
  let low = 0, band = 0;
  const q = 1 / Q;
  for (let i = 0; i < x.length; i++) {
    const f = 2 * Math.sin((Math.PI * fcAt(i / SR)) / SR);
    const high = x[i] - low - q * band;
    band += f * high;
    low += f * band;
    y[i] = band;
  }
  return y;
};
// very short reverb: a few soft early reflections, low-passed
const reverb = (x, mix) => {
  const taps = [[0.011, 0.3], [0.017, 0.22], [0.023, 0.16], [0.031, 0.1]];
  const tail = N(0.04);
  const wet = new Float32Array(x.length + tail);
  for (const [d, g] of taps) {
    const o = N(d);
    for (let i = 0; i < x.length; i++) wet[i + o] += g * x[i];
  }
  const wl = lp1(wet, 4500);
  const y = new Float32Array(x.length + tail);
  for (let i = 0; i < y.length; i++) y[i] = (i < x.length ? x[i] : 0) + mix * wl[i];
  return y;
};
const fade = (x, ms) => {
  const n = Math.min(x.length, N(ms / 1000));
  for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n;
  return x;
};
const finish = (x, { lpHz = 8000, rev = 0.12, maxSec }) => {
  let y = lp1(x, lpHz);
  y = reverb(y, rev);
  if (y.length > N(maxSec)) y = y.slice(0, N(maxSec));
  return fade(y, 18);
};

// ---- sounds -------------------------------------------------------------
const pop = (fs0, fe, dur) => {
  const x = new Float32Array(N(dur));
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = fe + (fs0 - fe) * Math.exp(-t * 38);
    ph += (2 * Math.PI * f) / SR;
    const att = Math.min(1, t / 0.004);
    const env = att * Math.exp(-t * 16);
    x[i] = env * (Math.sin(ph) + 0.15 * Math.sin(2 * ph) * Math.exp(-t * 30));
  }
  return finish(x, { lpHz: 7000, rev: 0.12, maxSec: 0.5 });
};

const click = () => {
  const n = noiseGen(7);
  const x = new Float32Array(N(0.09));
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const att = Math.min(1, t / 0.0008);
    x[i] = att * (n() * Math.exp(-t * 230) + 0.25 * Math.sin(2 * Math.PI * 1700 * t) * Math.exp(-t * 320));
  }
  const h = hp1(hp1(x, 2200), 2200);
  return finish(h, { lpHz: 9500, rev: 0.08, maxSec: 0.5 });
};

const whoosh = () => {
  const dur = 0.72;
  const n = noiseGen(21);
  const x = new Float32Array(N(dur));
  for (let i = 0; i < x.length; i++) x[i] = n();
  const fc = (t) => 450 * Math.pow(2800 / 450, Math.pow(t / dur, 0.85));
  const b = bandpass(x, fc, 1.3);
  for (let i = 0; i < b.length; i++) {
    const u = i / b.length;
    const env = Math.pow(Math.sin(Math.PI * Math.pow(u, 0.8)), 2); // soft in, soft out
    b[i] *= env;
  }
  return finish(b, { lpHz: 6000, rev: 0.1, maxSec: 0.8 });
};

const chime = () => {
  const base = 784;
  const partials = [[1, 1, 9], [2.0, 0.42, 12], [3.01, 0.18, 17], [4.2, 0.07, 24]];
  const x = new Float32Array(N(0.5));
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const att = Math.min(1, t / 0.004);
    let s = 0;
    for (const [m, a, d] of partials) {
      s += a * Math.exp(-t * d) * (Math.sin(2 * Math.PI * base * m * t) + Math.sin(2 * Math.PI * base * m * 1.003 * t));
    }
    x[i] = att * s * 0.5;
  }
  return finish(x, { lpHz: 7500, rev: 0.16, maxSec: 0.5 });
};

const thud = () => {
  const x = new Float32Array(N(0.34));
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 52 + 70 * Math.exp(-t * 20);
    ph += (2 * Math.PI * f) / SR;
    const att = Math.min(1, t / 0.008);
    x[i] = att * Math.exp(-t * 11) * Math.sin(ph);
  }
  return finish(x, { lpHz: 420, rev: 0.06, maxSec: 0.5 });
};

// ---- write --------------------------------------------------------------
const PEAK = 0.84; // all sounds peak-matched; per-event volume lives in src/sfxPlan.ts
const writeWav = (name, x) => {
  let pk = 0;
  for (const v of x) pk = Math.max(pk, Math.abs(v));
  const g = PEAK / pk;
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) buf.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(x[i] * g * 32767))), 44 + i * 2);
  fs.writeFileSync(new URL(name + ".wav", OUT), buf);
};

writeWav("pop", pop(620, 190, 0.3));
writeWav("pop2", pop(760, 240, 0.28)); // higher-pitch variant for consecutive pops
writeWav("click", click());
writeWav("whoosh", whoosh());
writeWav("chime", chime());
writeWav("thud", thud());
console.log("SFX written to public/sfx");
