// Verifies every SFX: duration, peak, clipping, RMS (loudness spread).
import fs from "node:fs";
const dir = new URL("../public/sfx/", import.meta.url);
const LIMIT = { whoosh: 0.8, default: 0.5 };
let bad = 0;
const rows = [];
for (const f of fs.readdirSync(dir).filter((f) => f.endsWith(".wav")).sort()) {
  const b = fs.readFileSync(new URL(f, dir));
  const sr = b.readUInt32LE(24);
  const n = (b.length - 44) / 2;
  let pk = 0, clip = 0, sum = 0;
  for (let i = 0; i < n; i++) {
    const v = b.readInt16LE(44 + i * 2);
    pk = Math.max(pk, Math.abs(v));
    if (Math.abs(v) >= 32767) clip++;
    sum += v * v;
  }
  const dur = n / sr;
  const rms = Math.sqrt(sum / n) / 32768;
  const name = f.replace(".wav", "");
  const max = LIMIT[name] ?? LIMIT.default;
  const ok = dur <= max && clip === 0 && pk / 32768 < 0.95;
  if (!ok) bad++;
  rows.push({ name, dur: +dur.toFixed(3), max, peak_dB: +(20 * Math.log10(pk / 32768)).toFixed(2), rms_dB: +(20 * Math.log10(rms)).toFixed(2), clip, ok });
}
console.table(rows);
console.log(bad ? "SFX CHECK FAILED" : "SFX CHECK OK");
process.exit(bad ? 1 : 0);
